import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type OrderDocument = Order & Document;

// Schema สำหรับ customerInfo (ข้อมูลลูกค้า)
@Schema({ _id: false })
class CustomerInfo {
  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  address: string;
}

// Schema สำหรับ items (สินค้าในตะกร้า)
@Schema({ _id: false })
class CartItem {
  @Prop()
  _id: string;

  @Prop()
  name: string;

  @Prop()
  price: number;

  @Prop()
  quantity: number;
}

// Schema หลัก (Order)
@Schema({ timestamps: true })
export class Order extends Document {
  @Prop({ type: [CartItem] })
  items: CartItem[];

  @Prop({ required: true })
  total: number;

  @Prop({ type: CustomerInfo, required: true }) // <-- 4. ใช้ @Prop({ type: CustomerInfo, ... }) (ตามโค้ดของคุณ)
  customerInfo: CustomerInfo;
}

export const OrderSchema = SchemaFactory.createForClass(Order);
