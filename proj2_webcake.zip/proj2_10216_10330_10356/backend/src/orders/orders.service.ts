import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Order, OrderDocument } from './schemas/order.schema';
import { CreateOrderDto } from './dto/create-order.dto';

@Injectable()
export class OrdersService {
  constructor(
    @InjectModel(Order.name) private orderModel: Model<OrderDocument>,
  ) {}

  // Logic การบันทึกลง MongoDB
  async create(createOrderDto: CreateOrderDto): Promise<Order> {
    const newOrder = new this.orderModel({
      ...createOrderDto,
      createdAt: new Date(), // เพิ่ม timestamp
    });
    return newOrder.save();
  }
}
