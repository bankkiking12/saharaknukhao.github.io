import { Controller, Post, Body, HttpCode, HttpStatus } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/create-order.dto';

@Controller('orders') // <-- นี่คือการสร้าง Endpoint /orders
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @Post() // <-- นี่คือการสร้าง API POST /orders
  @HttpCode(HttpStatus.CREATED) // ตอบกลับด้วย 201 Created
  async create(@Body() createOrderDto: CreateOrderDto) {
    // ส่งข้อมูลที่ได้จาก Front-end (cartItems, total, customerInfo)
    // ไปให้ Service เพื่อบันทึกลง Database
    return this.ordersService.create(createOrderDto);
  }
}
