class CustomerInfoDto {
  readonly name: string;
  readonly address: string;
}

class CartItemDto {
  readonly _id: string;
  readonly name: string;
  readonly price: number;
  readonly quantity: number;
}

export class CreateOrderDto {
  readonly items: CartItemDto[];
  readonly total: number;
  readonly customerInfo: CustomerInfoDto;
}
