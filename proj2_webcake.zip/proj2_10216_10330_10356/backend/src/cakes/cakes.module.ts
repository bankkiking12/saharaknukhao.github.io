import { Module } from '@nestjs/common';
import { CakesService } from './cakes.service';
import { CakesController } from './cakes.controller';

// 1. Import MongooseModule และ Schema ของเรา
import { MongooseModule } from '@nestjs/mongoose';
import { Cake, CakeSchema } from './schemas/cake.schema';

@Module({
  // 2. เพิ่ม MongooseModule.forFeature เข้าไปใน imports
  // เพื่อ "ลงทะเบียน" Model ให้ Service นี้รู้จัก
  imports: [
    MongooseModule.forFeature([{ name: Cake.name, schema: CakeSchema }]),
  ],
  controllers: [CakesController],
  providers: [CakesService],
})
export class CakesModule {}
