import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CreateCakeDto } from './dto/create-cake.dto';
import { UpdateCakeDto } from './dto/update-cake.dto';
import { Cake, CakeDocument } from './schemas/cake.schema';

@Injectable()
export class CakesService {
  // ฉีด Model เข้ามา
  constructor(@InjectModel(Cake.name) private cakeModel: Model<CakeDocument>) {}

  // C - Create
  async create(createCakeDto: CreateCakeDto): Promise<Cake> {
    const createdCake = new this.cakeModel(createCakeDto);
    return createdCake.save();
  }

  // R - Read All
  async findAll(): Promise<Cake[]> {
    return this.cakeModel.find().exec();
  }

  // R - Read One
  findOne(id: string) {
    return this.cakeModel.findById(id).exec();
  }

  // U - Update
  update(id: string, updateCakeDto: UpdateCakeDto) {
    return this.cakeModel.findByIdAndUpdate(id, updateCakeDto, { new: true }).exec();
  }

  // D - Delete
  remove(id: string) {
    return this.cakeModel.findByIdAndDelete(id).exec();
  }
}