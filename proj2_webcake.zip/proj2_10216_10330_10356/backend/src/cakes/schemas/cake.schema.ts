import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CakeDocument = Cake & Document;

@Schema()
export class Cake {
  @Prop({ required: true })
  name: string;

  @Prop()
  description: string;

  @Prop({ required: true })
  price: number;

  @Prop()
  imageUrl: string;
  
  @Prop({ default: 'เค้กทั่วไป' })
  category: string;
}

export const CakeSchema = SchemaFactory.createForClass(Cake);