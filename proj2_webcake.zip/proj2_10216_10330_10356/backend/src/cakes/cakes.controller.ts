import {
  Controller,
  Get,
  Post,
  Body,
  Put, // 1. <-- เปลี่ยนจาก Patch เป็น Put
  Param, // 2. <-- Import Param (สำหรับ :id)
  Delete, // 3. <-- Import Delete
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { CakesService } from './cakes.service';
import { CreateCakeDto } from './dto/create-cake.dto';
import { UpdateCakeDto } from './dto/update-cake.dto';

@Controller('cakes')
export class CakesController {
  constructor(private readonly cakesService: CakesService) {}

  @Post() // (C) Create - คุณน่าจะมีอยู่แล้ว
  create(@Body() createCakeDto: CreateCakeDto) {
    return this.cakesService.create(createCakeDto);
  }

  @Get() // (R) Read All - คุณน่าจะมีอยู่แล้ว
  findAll() {
    return this.cakesService.findAll();
  }

  // 4. --- เพิ่มส่วนนี้ --- (U) Update
  // ใช้ Put เพื่อให้ตรงกับ cakeSlice.js
  // นี่คือ API ที่แก้ Error 404 ครับ
  @Put(':id') // <-- เปลี่ยนจาก Patch เป็น Put
  update(@Param('id') id: string, @Body() updateCakeDto: UpdateCakeDto) {
    return this.cakesService.update(id, updateCakeDto);
  }

  // 5. --- เพิ่มส่วนนี้ --- (D) Delete
  @Delete(':id') // <-- ตรงกับ /cakes/:id
  @HttpCode(HttpStatus.NO_CONTENT) // ตอบ 204 No Content
  remove(@Param('id') id: string) {
    return this.cakesService.remove(id);
  }
}
