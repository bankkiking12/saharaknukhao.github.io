// DTO (Data Transfer Object)
export class CreateCakeDto {
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
}
