import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeItem, updateQuantity } from '../store/cartSlice.js';
import { Link } from 'react-router-dom';

const CartPage = () => {
  const dispatch = useDispatch();
  // 1. ดึงข้อมูลจาก Redux store
  const cartItems = useSelector((state) => state.cart.items);

  // 2. คำนวณราคารวม
  const totalPrice = cartItems.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  // 3. ฟังก์ชันสำหรับจัดการการเปลี่ยนจำนวน
  const handleQuantityChange = (item, newQuantity) => {
    dispatch(updateQuantity({ _id: item._id, quantity: Number(newQuantity) }));
  };
  
  // 4. ฟังก์ชันสำหรับลบ
  const handleRemove = (id) => {
    dispatch(removeItem(id));
  };

  // 5. กรณีตะกร้าว่าง
  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto p-8 text-center">
        <h1 className="text-4xl font-bold text-text-dark mb-8">ตะกร้าสินค้า</h1>
        <div className="bg-white p-10 rounded-xl shadow-lg">
          <p className="text-2xl text-gray-500">ตะกร้าของคุณว่างเปล่า 😅</p>
          <Link 
            to="/cakes"
            className="mt-6 inline-block bg-primary-pink text-text-dark font-bold py-3 px-8 rounded-full hover:bg-pink-300"
          >
            เลือกซื้อเค้ก
          </Link>
        </div>
      </div>
    );
  }

  // 6. กรณีมีสินค้าในตะกร้า
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-4xl font-bold text-text-dark mb-8 text-center">ตะกร้าสินค้า</h1>
      <div className="bg-white p-6 rounded-xl shadow-lg">
        {/* วนลูปแสดงสินค้า */}
        {cartItems.map((item) => (
          <div key={item._id} className="flex items-center justify-between border-b py-4">
            <div className="flex items-center space-x-4">
              <img src={item.imageUrl} alt={item.name} className="w-20 h-20 object-cover rounded-lg" />
              <div>
                <h2 className="text-xl font-bold text-text-dark">{item.name}</h2>
                <p className="text-gray-500">฿{item.price.toFixed(2)}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <input 
                type="number"
                min="1"
                value={item.quantity}
                onChange={(e) => handleQuantityChange(item, e.target.value)}
                className="w-16 text-center border rounded p-2"
              />
              <p className="text-lg font-semibold w-24 text-right">
                ฿{(item.price * item.quantity).toFixed(2)}
              </p>
              <button 
                onClick={() => handleRemove(item._id)}
                className="text-red-500 hover:text-red-700 font-bold"
              >
                X
              </button>
            </div>
          </div>
        ))}

        {/* สรุปยอด */}
        <div className="mt-6 flex justify-end">
          <div className="text-right">
            <h2 className="text-3xl font-bold text-text-dark">
              ยอดรวม: ฿{totalPrice.toFixed(2)}
            </h2>
            <Link 
              to="/checkout"
              className="mt-4 w-full block text-center bg-green-500 text-white font-bold text-lg py-3 px-8 rounded-full shadow-lg hover:bg-green-600"
            >
              ไปหน้าชำระเงิน
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;