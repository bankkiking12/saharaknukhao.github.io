import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchCakes, addCake, updateCake, deleteCake } from '../store/cakeSlice';

const AdminPage = () => {
  const dispatch = useDispatch();
  const cakes = useSelector((state) => state.cakes.items);
  const cakeStatus = useSelector((state) => state.cakes.status);

  // State สำหรับ Form
  const [formState, setFormState] = useState({
    name: '',
    description: '',
    price: 0,
    imageUrl: ''
  });
  
  // State สำหรับเก็บ ID ของเค้กที่กำลังแก้ไข (ถ้าเป็น null = โหมดเพิ่มใหม่)
  const [editingId, setEditingId] = useState(null);

  // ดึงข้อมูลเค้กเมื่อ Component โหลด
  useEffect(() => {
    if (cakeStatus === 'idle') {
      dispatch(fetchCakes());
    }
  }, [cakeStatus, dispatch]);

  // เมื่อมีการเปลี่ยนแปลงใน Form Input
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormState(prevState => ({
      ...prevState,
      [name]: name === 'price' ? Number(value) : value // แปลง price เป็นตัวเลข
    }));
  };
  
  // เมื่อกดปุ่ม "เพิ่ม" หรือ "อัปเดต"
  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingId) {
      // โหมดอัปเดต
      dispatch(updateCake({ _id: editingId, ...formState }));
    } else {
      // โหมดเพิ่มใหม่
      dispatch(addCake(formState));
    }
    // เคลียร์ Form และยกเลิกโหมดแก้ไข
    resetForm();
  };
  
  // เมื่อกดปุ่ม "แก้ไข" ที่รายการเค้ก
  const handleEdit = (cake) => {
    setEditingId(cake._id); // เข้าสู่โหมดแก้ไข
    setFormState({ // เอาข้อมูลเค้กมาใส่ใน Form
      name: cake.name,
      description: cake.description,
      price: cake.price,
      imageUrl: cake.imageUrl
    });
  };
  
  // เมื่อกดปุ่ม "ลบ"
  const handleDelete = (id) => {
    if (window.confirm('คุณแน่ใจหรือไม่ว่าต้องการลบเค้กนี้?')) {
      dispatch(deleteCake(id));
    }
  };

  // ฟังก์ชันเคลียร์ Form
  const resetForm = () => {
    setEditingId(null);
    setFormState({ name: '', description: '', price: 0, imageUrl: '' });
  };

  return (
    <div className="container mx-auto p-8 grid grid-cols-1 md:grid-cols-3 gap-8">
      
      {/* --- ส่วน Form (C/U) --- */}
      <div className="md:col-span-1">
        <div className="bg-white p-6 rounded-xl shadow-lg sticky top-24">
          <h2 className="text-3xl font-bold text-text-dark mb-6">
            {editingId ? 'แก้ไขเค้ก' : 'เพิ่มเค้กใหม่'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">ชื่อเค้ก</label>
              <input type="text" name="name" value={formState.name} onChange={handleChange} required
                     className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">คำอธิบาย</label>
              <textarea name="description" value={formState.description} onChange={handleChange}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">ราคา (บาท)</label>
              <input type="number" name="price" min="0" value={formState.price} onChange={handleChange} required
                     className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">URL รูปภาพ</label>
              <input type="text" name="imageUrl" value={formState.imageUrl} onChange={handleChange}
                     className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" />
            </div>
            <div className="flex space-x-2">
              <button type="submit"
                      className="flex-1 bg-blue-500 text-white font-bold py-2 px-4 rounded-full hover:bg-blue-600">
                {editingId ? 'บันทึกการแก้ไข' : 'เพิ่มเค้ก'}
              </button>
              {editingId && (
                <button type="button" onClick={resetForm}
                        className="bg-gray-300 text-text-dark font-bold py-2 px-4 rounded-full hover:bg-gray-400">
                  ยกเลิก
                </button>
              )}
            </div>
          </form>
        </div>
      </div>

      {/* --- ส่วนแสดงรายการ (R/D) --- */}
      <div className="md:col-span-2">
        <h1 className="text-4xl font-bold text-text-dark mb-8">
          จัดการรายการเค้ก
        </h1>
        <div className="space-y-4">
          {cakes.map((cake) => (
            <div key={cake._id} className="bg-white p-4 rounded-xl shadow-lg flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <img src={cake.imageUrl || 'https://via.placeholder.com/100'} alt={cake.name}
                     className="w-20 h-20 object-cover rounded-lg" />
                <div>
                  <h3 className="text-xl font-bold text-text-dark">{cake.name}</h3>
                  <p className="text-gray-500">฿{cake.price}</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <button onClick={() => handleEdit(cake)}
                        className="bg-yellow-400 text-text-dark font-bold py-2 px-4 rounded-full hover:bg-yellow-500">
                  แก้ไข
                </button>
                <button onClick={() => handleDelete(cake._id)}
                        className="bg-red-500 text-white font-bold py-2 px-4 rounded-full hover:bg-red-600">
                  ลบ
                </button>
              </div>
            </div>
          ))}

          {cakes.length === 0 && cakeStatus === 'succeeded' && (
            <div className="text-center p-10 bg-white rounded-lg shadow-md">
              <h2 className="text-2xl text-gray-500">ยังไม่มีเค้กในเมนู 😅</h2>
              <p className="text-gray-400 mt-2">
                (กรุณาใช้ Form ด้านซ้ายเพื่อ "เพิ่มเค้กใหม่" ลงใน Database)
              </p>
            </div>
          )}
        </div>
      </div>

    </div>
  );
};

export default AdminPage;