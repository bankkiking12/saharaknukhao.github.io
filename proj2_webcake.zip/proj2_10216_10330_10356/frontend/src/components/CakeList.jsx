import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchCakes } from '../store/cakeSlice.js';
import { addItem } from '../store/cartSlice.js'; // 1. Import addItem

const CakeList = () => {
  const dispatch = useDispatch(); // 2. สร้างตัว dispatch
  const cakes = useSelector((state) => state.cakes.items);
  const cakeStatus = useSelector((state) => state.cakes.status);

  useEffect(() => {
    if (cakeStatus === 'idle') {
      dispatch(fetchCakes());
    }
  }, [cakeStatus, dispatch]);

  if (cakeStatus === 'loading') {
    return <div className="text-center p-10 text-text-dark">กำลังโหลดเค้ก... 🍰</div>;
  }
  
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-4xl font-bold text-center text-text-dark mb-8">
        เมนูเค้กของเรา
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {cakes.map((cake) => (
          <div 
            key={cake._id} 
            className="bg-white rounded-xl shadow-lg overflow-hidden transition-transform hover:scale-105"
          >
            <img src={cake.imageUrl || 'https://via.placeholder.com/400x300.png/FFD1DC/4A4A4A?text=naminami+cake'} 
                 alt={cake.name} 
                 className="w-full h-56 object-cover" />
            
            <div className="p-6">
              <h2 className="text-2xl font-bold text-text-dark mb-2">{cake.name}</h2>
              <p className="text-gray-600 mb-4">{cake.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold text-pink-500">
                  ฿{cake.price}
                </span>
                
                {/* 3. เพิ่ม onClick ให้ปุ่มนี้ */}
                <button 
                  onClick={() => dispatch(addItem(cake))}
                  className="bg-primary-pink text-text-dark font-bold py-2 px-4 rounded-full hover:bg-pink-300"
                >
                  เพิ่มลงตะกร้า
                </button>
              </div>
            </div>
          </div>
        ))}

      </div>

      {/* --- กรณีไม่มีสินค้าใน Database --- */}
      {cakes.length === 0 && cakeStatus === 'succeeded' && (
        <div className="text-center p-10 bg-white rounded-lg shadow-md">
          <h2 className="text-2xl text-gray-500">ยังไม่มีเค้กในเมนู 😅</h2>
          <p className="text-gray-400 mt-2">
            (กรุณาไปที่ MongoDB Compass แล้ว "ADD DATA" ลงใน Collection 'cakes' ก่อนครับ)
          </p>
        </div>
      )}

    </div>
  );
};

export default CakeList;