import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { clearCart } from '../store/cartSlice'; // 1. <-- ย้าย clearCart มาที่นี่
import { Link } from 'react-router-dom';
import axios from 'axios'; // 2. <-- ย้าย axios มาที่นี่

const CheckoutPage = () => {
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.items);
  const [orderSuccess, setOrderSuccess] = useState(false);
  
  // 3. State สำหรับเก็บข้อมูล Form
  const [customerName, setCustomerName] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');

  const totalPrice = cartItems.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  // 4. <-- ย้าย handleCheckout มาที่นี่
  const handleCheckout = async (e) => {
    e.preventDefault();
    
    // (เพิ่ม Validation ตรวจสอบว่ากรอกชื่อ/ที่อยู่หรือยัง)
    if (!customerName || !customerAddress) {
      alert("กรุณากรอกชื่อและที่อยู่");
      return;
    }

    try {
      await axios.post('http://localhost:3000/orders', {
        items: cartItems,
        total: totalPrice,
        customerInfo: { // 6. <-- ส่งข้อมูลลูกค้าไปด้วย
          name: customerName,
          address: customerAddress,
        }
      });
      
      dispatch(clearCart()); 
      setOrderSuccess(true);
      
    } catch (err) {
      console.error('Checkout ไม่สำเร็จ:', err);
    }
  };

  if (orderSuccess) {
    return (
      <div className="container mx-auto p-8 text-center">
        <div className="bg-white p-12 rounded-xl shadow-lg">
          <h1 className="text-4xl font-bold text-green-500 mb-4">ขอบคุณสำหรับ Order ครับ! 💖</h1>
           <Link 
            to="/" 
            className="mt-6 inline-block bg-primary-pink text-text-dark font-bold text-lg py-3 px-8 rounded-full shadow-lg hover:bg-pink-300 transition-colors"
          >
            กลับไปหน้าแรก
          </Link>
        </div>
      </div>
    );
  }
  

  if (cartItems.length === 0) {
     return (
        <div className="container mx-auto p-8 text-center">
          <h1 className="text-2xl text-gray-500">ไม่มีสินค้าในตะกร้า</h1>
           <Link to="/cakes" className="mt-6 inline-block bg-primary-pink ...">
            เลือกซื้อเค้ก
          </Link>
        </div>
     );
  }

  // 9. --- แสดงฟอร์ม Checkout ---
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-4xl font-bold text-text-dark mb-8 text-center">ยืนยันการสั่งซื้อ</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* ส่วนสรุป Order */}
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-2xl font-bold mb-4 border-b pb-2">สรุปรายการ</h2>
          {cartItems.map(item => (
            <div key={item._id} className="flex justify-between items-center mb-2">
              <span className="font-medium">{item.name} x {item.quantity}</span>
              <span className="text-gray-600">฿{(item.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}
          <div className="border-t mt-4 pt-4 flex justify-between">
            <h3 className="text-xl font-bold">ยอดรวม</h3>
            <h3 className="text-xl font-bold text-pink-500">฿{totalPrice.toFixed(2)}</h3>
          </div>
        </div>

        {/* ส่วนฟอร์มกรอกข้อมูล */}
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <h2 className="text-2xl font-bold mb-4">ข้อมูลการจัดส่ง</h2>
          <form onSubmit={handleCheckout}>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-2">ชื่อ-สกุล</label>
              <input 
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full p-3 border rounded-lg focus:outline-pink-300"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-2">ที่อยู่</label>
              <textarea
                value={customerAddress}
                onChange={(e) => setCustomerAddress(e.target.value)}
                className="w-full p-3 border rounded-lg focus:outline-pink-300"
                rows="3"
                required
              />
            </div>

            {/* ปุ่มยืนยันสุดท้าย */}
            <button 
              type="submit"
              className="mt-4 w-full bg-green-500 text-white font-bold text-lg py-3 px-8 rounded-full shadow-lg hover:bg-green-600"
            >
              ยืนยันการสั่งซื้อ
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};

export default CheckoutPage;
