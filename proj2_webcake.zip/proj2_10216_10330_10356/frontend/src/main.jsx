import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css' // <-- Tailwind CSS

// 1. Import Store และ Provider
import { store } from './store/store.js'
import { Provider } from 'react-redux'

// 2. !!! IMPORT BROWSERROUTER !!!
import { BrowserRouter } from 'react-router-dom'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Provider store={store}>
      {/* 3. !!! หุ้ม APP ด้วย BROWSERROUTER !!! */}
      <BrowserRouter> 
        <App />
      </BrowserRouter>
    </Provider>
  </React.StrictMode>,
)