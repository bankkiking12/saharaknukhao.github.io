import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// API URL ของ Backend
const API_URL = 'http://localhost:3000/cakes';

// 1. READ (R) - (มีอยู่แล้ว)
export const fetchCakes = createAsyncThunk(
  'cakes/fetchCakes',
  async () => {
    const response = await axios.get(API_URL);
    return response.data;
  }
);

// 2. CREATE (C) - (เพิ่มใหม่)
export const addCake = createAsyncThunk(
  'cakes/addCake',
  async (newCake) => {
    const response = await axios.post(API_URL, newCake);
    return response.data; // Server ควรส่งข้อมูลเค้กที่สร้าง (พร้อม _id) กลับมา
  }
);

// 3. UPDATE (U) - (เพิ่มใหม่)
export const updateCake = createAsyncThunk(
  'cakes/updateCake',
  async (cakeData) => {
    // แยก _id ออกจากข้อมูลที่จะอัปเดต
    const { _id, ...fieldsToUpdate } = cakeData;
    const response = await axios.put(`${API_URL}/${_id}`, fieldsToUpdate);
    return response.data; // Server ควรส่งข้อมูลที่อัปเดตกลับมา
  }
);

// 4. DELETE (D) - (เพิ่มใหม่)
export const deleteCake = createAsyncThunk(
  'cakes/deleteCake',
  async (id) => {
    await axios.delete(`${API_URL}/${id}`);
    return id; // ส่ง id กลับไปให้ Reducer ใช้ลบใน state
  }
);


// 2. สร้าง Slice
const cakeSlice = createSlice({
  name: 'cakes',
  initialState: {
    items: [], // ที่เก็บเค้กทั้งหมด
    status: 'idle', // 'idle' | 'loading' | 'succeeded' | 'failed'
    error: null
  },
  reducers: {
    // (ยังไม่ใช้)
  },
  // 3. จัดการสถานะของ Thunk ทั้งหมด (C/R/U/D)
  extraReducers: (builder) => {
    builder
      // READ
      .addCase(fetchCakes.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchCakes.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.items = action.payload; // เอาข้อมูลที่ดึงได้มาเก็บ
      })
      .addCase(fetchCakes.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
      
      // CREATE
      .addCase(addCake.fulfilled, (state, action) => {
        state.items.push(action.payload); // เพิ่มเค้กใหม่เข้าไปใน state
      })
      
      // UPDATE
      .addCase(updateCake.fulfilled, (state, action) => {
        const updatedCake = action.payload;
        // ค้นหา index ของเค้กที่ถูกอัปเดต
        const index = state.items.findIndex(cake => cake._id === updatedCake._id);
        if (index !== -1) {
          state.items[index] = updatedCake; // แทนที่ด้วยข้อมูลใหม่
        }
      })
      
      // DELETE
      .addCase(deleteCake.fulfilled, (state, action) => {
        const deletedId = action.payload;
        // กรองเค้กที่ถูกลบออกจาก state
        state.items = state.items.filter(cake => cake._id !== deletedId);
      });
  }
});

export default cakeSlice.reducer;
