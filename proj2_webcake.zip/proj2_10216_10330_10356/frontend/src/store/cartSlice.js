import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  items: [], // [{ id, name, price, quantity, ... }]
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    // 1. เพิ่มสินค้า
    addItem: (state, action) => {
      const newItem = action.payload;
      const existingItem = state.items.find(item => item._id === newItem._id);
      
      if (existingItem) {
        // ถ้ามีอยู่แล้ว ให้เพิ่มจำนวน
        existingItem.quantity += 1;
      } else {
        // ถ้าเป็นสินค้าใหม่ ให้เพิ่มเข้าไปใน Array
        state.items.push({ ...newItem, quantity: 1 });
      }
    },
    
    // 2. ลบสินค้า
    removeItem: (state, action) => {
      const idToRemove = action.payload;
      state.items = state.items.filter(item => item._id !== idToRemove);
    },
    
    // 3. อัปเดตจำนวน (เช่น + หรือ - ในตะกร้า)
    updateQuantity: (state, action) => {
      const { _id, quantity } = action.payload;
      const itemToUpdate = state.items.find(item => item._id === _id);
      
      if (itemToUpdate) {
        itemToUpdate.quantity = quantity;
      }
      
      // ถ้าน้อยกว่า 1 ให้ลบทิ้ง
      if (quantity < 1) {
        state.items = state.items.filter(item => item._id !== _id);
      }
    },
    
    // 4. ล้างตะกร้า (เมื่อสั่งซื้อเสร็จ)
    clearCart: (state) => {
      state.items = [];
    }
  }
});

// ส่ง Actions ออกไปให้ Component อื่นใช้
export const { addItem, removeItem, updateQuantity, clearCart } = cartSlice.actions;

// ส่ง Reducer ออกไปให้ Store
export default cartSlice.reducer;