import { configureStore } from '@reduxjs/toolkit';
import cakeReducer from './cakeSlice.js';
import cartReducer from './cartSlice.js'; // 1. Import เข้ามา

export const store = configureStore({
  reducer: {
    cakes: cakeReducer,
    cart: cartReducer, // 2. เพิ่มลิ้นชัก cart
  },
});