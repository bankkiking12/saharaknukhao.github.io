import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css'; // <--- ไฟล์ CSS ของ Tailwind
import App from './App';

// 1. Import Store และ Provider
import { store } from './store/store';
import { Provider } from 'react-redux';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* 2. หุ้ม App ด้วย Provider และส่ง store เข้าไป */}
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>
);