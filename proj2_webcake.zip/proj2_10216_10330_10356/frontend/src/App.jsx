import React, { useEffect, useState } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux'; // 2. <-- Import useDispatch
import { fetchCakes } from './store/cakeSlice'; // 3. <-- แก้ไข Path
import { addItem } from './store/cartSlice'; // 4. <-- แก้ไข Path

// 5. --- Import Component ---
import CakeList from './components/CakeList'; 
import CartPage from './components/CartPage'; 
import AdminPage from './components/AdminPage';
import CheckoutPage from './components/CheckoutPage'; 

// --- 1. ย้าย HomePage ออกมา ---
const HomePage = () => {
  const dispatch = useDispatch();
  const cakes = useSelector((state) => state.cakes.items);
  const cakeStatus = useSelector((state) => state.cakes.status);

  // 2. --- ดึงข้อมูลเค้ก (เหมือน CakeList) ---
  useEffect(() => {
    if (cakeStatus === 'idle') {
      dispatch(fetchCakes());
    }
  }, [cakeStatus, dispatch]);

  // 3. --- เลือกมาแค่ 3 ชิ้น ---
  const featuredCakes = cakes.slice(0, 3);

  return (
    <div className="container mx-auto px-6 py-10">
      {/* --- 4. Banner ต้อนรับ --- */}
      <div 
        className="bg-white p-12 rounded-xl shadow-2xl text-center mb-16 relative overflow-hidden" 
        style={{
          backgroundImage: 'url(https://placehold.co/1000x400/FFF5F7/FFD1DC?text=Welcome!)', // 5. <-- เปลี่ยน URL
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <h1 className="text-5xl font-bold text-text-dark mb-4 z-10 relative">
          ยินดีต้อนรับสู่ <span className="text-pink-800">naminami cake</span>
        </h1>
        <p className="text-xl text-gray-600 mb-8 z-10 relative">
          เค้กโฮมเมด สดใหม่ อร่อยทุกคำ
        </p>
        <Link 
          to="/cakes" 
          className="bg-primary-pink text-text-dark font-bold text-lg py-3 px-8 rounded-full shadow-lg hover:bg-pink-300 transition-colors z-10 relative"
        >
          ดูเมนูเค้กทั้งหมด 🍰
        </Link>
      </div>

      {/* --- 5. ส่วนเค้กแนะนำ --- */}
      <h2 className="text-3xl font-bold text-center text-text-dark mb-8">
        เค้กแนะนำของเรา 🧁
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {featuredCakes.map((cake) => (
          <div 
            key={cake._id} 
            className="bg-white rounded-xl shadow-lg overflow-hidden transition-transform hover:scale-105"
          >
            <img 
              src={cake.imageUrl || 'https://placehold.co/400x300/FFD1DC/4A4A4A?text=naminami+cake'} 
              alt={cake.name} 
              className="w-full h-56 object-cover" 
            />
            <div className="p-6">
              <h2 className="text-2xl font-bold text-text-dark mb-2">{cake.name}</h2>
              <p className="text-gray-600 mb-4 h-20 overflow-hidden">{cake.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold text-pink-500">
                  ฿{cake.price}
                </span>
                <button 
                  onClick={() => dispatch(addItem(cake))}
                  className="bg-primary-pink text-text-dark font-bold py-2 px-4 rounded-full hover:bg-pink-300"
                >
                  เพิ่มลงตะกร้า
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};


// --- 6. สร้าง Footer Component ใหม่ ---
const Footer = () => {
  // --- Icon SVGs (เพื่อให้แสดงผลได้เลย) ---
  const icons = {
    line: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>,
    facebook: <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3V2z" /></svg>,
    instagram: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><rect x={2} y={2} width={20} height={20} rx={5} ry={5} /><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z" /><line x1="17.5" y1="6.5" x2="17.51" y2="6.5" /></svg>,
    tiktok: <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M16.6 5.82s.51-6.26-4.21-6.26v6.49c0 .71.58 1.29 1.29 1.29h2.92v6.49c0 4.1-3.36 7.46-7.46 7.46s-7.46-3.36-7.46-7.46 3.36-7.46 7.46-7.46c.14 0 .28 0 .41.01v-6.5c-4.99 0-9.05 4.06-9.05 9.05s4.06 9.05 9.05 9.05 9.05-4.06 9.05-9.05V5.82z" /></svg>,
    twitter: <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z" /></svg>,
    phone: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>,
  };

  const contactLinks = [
    { icon: icons.line, title: "LINE ID:", text: "@naminami cake" },
    { icon: icons.facebook, title: "Facebook:", text: "www.facebook.com/naminami cake" },
    { icon: icons.instagram, title: "Instagram:", text: "www.instagram.com/naminami cakee" },
    { icon: icons.tiktok, title: "Tiktok:", text: "www.tiktok.com/@naminami cake" },
    { icon: icons.twitter, title: "Twitter:", text: "www.twitter.com/naminami cake" },
    { icon: icons.phone, title: "โทร:", text: "012-345-6789" },
  ];

  return (
    <footer className="bg-white mt-16 py-12 shadow-inner border-t">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-text-dark mb-8">
          ช่องทางการติดต่อ
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6 max-w-4xl mx-auto">
          {contactLinks.map((item) => (
            <div key={item.title} className="flex items-center space-x-3">
              <span className="text-pink-500">{item.icon}</span>
              <div>
                <h4 className="font-bold text-text-dark">{item.title}</h4>
                <p className="text-gray-600">{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </footer>
  );
};


// --- 7. App หลัก ---
function App() {
  const cartItems = useSelector((state) => state.cart.items);
  const totalQuantity = cartItems.reduce((total, item) => total + item.quantity, 0);

  return (
    <div className="min-h-screen bg-secondary-pink">
      
      <nav className="bg-white shadow-md p-4 sticky top-0 z-10">
        <div className="container mx-auto flex justify-between items-center">
          <Link to="/" className="text-3xl font-bold text-primary-pink">
            naminami cake 🎂
          </Link>
          <div className="space-x-6 font-medium">
            <Link to="/" className="text-text-dark hover:text-primary-pink">หน้าแรก</Link>
            <Link to="/cakes" className="text-text-dark hover:text-primary-pink">เมนูเค้ก </Link>
            
            {/* 8. --- แก้ไขป้ายตะกร้า (ย้าย 'relative' เข้าไป) --- */}
            <Link to="/cart" className="text-text-dark hover:text-primary-pink relative">
              ตะกร้า
              {totalQuantity > 0 && (
                <span className="absolute -top-3 -right-4 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {totalQuantity}
                </span>
              )}
            </Link>

            <Link to="/admin" className="text-text-dark hover:text-primary-pink">Admin </Link>
          </div>
        </div>
      </nav>

      {/* 9. --- ส่วนแสดงเนื้อหาตาม URL --- */}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/cakes" element={<CakeList />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/checkout" element={<CheckoutPage />} /> 
      </Routes>
      
      {/* 10. --- เพิ่ม Footer ที่นี่ --- */}
      <Footer />

    </div>
  );
}

export default App;