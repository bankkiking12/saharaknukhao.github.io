/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}", // สำคัญมาก
  ],
  theme: {
    extend: {
      // ธีมสีชมพู-ขาวของเรา
      colors: {
        'primary-pink': '#FFD1DC',
        'secondary-pink': '#FFF5F7',
        'text-dark': '#4A4A4A',
      }
    },
  },
  plugins: [],
}